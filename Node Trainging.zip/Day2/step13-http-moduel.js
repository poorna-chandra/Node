var http=require("http");
var fs=require("fs");
var port=1234;
var host="localhost";
var server = http.createServer(function(req,res){
    res.writeHead(200,{"Content-Type" : "text\html"});
    // res.write("hello there"); 
    console.log(req.url);
    if(req.url === "/mymodules/index.html"){
        console.log("==============")
        var data = fs.readFileSync("/mymodules/welcome.html");
        res.write(data+"")
    };


     res.write("<h1>hello from node server1<h1>");
     res.end();
});

server.listen(port,host,function(error){
    if(error){
        console.log("error : "+error);
    }else{
        console.log("http server created on 1234");           }
})