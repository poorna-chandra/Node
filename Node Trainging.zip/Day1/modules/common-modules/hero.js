var Hero={
   title : "Batman",
   power : 10
};

// module.exports.Hero = "Batman";

module.exports.Hero = Hero;

module.exports.power = function power(){
    return 10;
};

function secret(){
  return "It is a secret";
};

var heros ={
    hero1 : {
      title : "HERO1",
      power : 1
    },
    hero2 : {
        title : "HERO2",
        power : 2
    },
    hero3 : {
        title : "HERO3",
        power : 3
    }
};

module.exports.Heros = heros;



