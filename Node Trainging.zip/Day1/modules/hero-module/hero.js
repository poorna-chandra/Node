export class hero {
    constructor(fn){
       this.fname =fn;
       this._scerect="******";            
     }
     sayname(){
         return "my name is "+this.fname;
     }
     set secrect(msg){
       this._scerect=msg;
     }
     get secrect(){
         return this._scerect;
     }
}