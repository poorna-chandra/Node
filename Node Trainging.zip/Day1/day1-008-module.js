var heroDetails=require("./modules/common-modules/hero.js")
console.log(heroDetails.Hero.title);
console.log(heroDetails.power());
console.log(heroDetails.Heros);