var fs=require("fs");
fs.readFile("data.json",function(err,data){
    if(err){
        console.log(err);
    }else{
        console.log(" data : "+JSON.parse(data).Heros[0]);
    }
})