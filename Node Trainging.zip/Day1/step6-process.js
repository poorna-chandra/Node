var eventemitter = require("events").EventEmitter ;
var ee=new eventemitter();
var si;
var count=1;

process.nextTick(function(){
    si = setInterval(function(){
        ee.emit("Infinte","My info");
        count++;
        if(count>5){
            clearInterval(si);
        }
    })
},2000);

ee.addListener("Infinte",function(){
    console.log(" myevent happened");
});
