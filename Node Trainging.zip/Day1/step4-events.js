var eventemitter = require("events").EventEmitter ;

var ee=new eventemitter();

ee.addListener("myevent",function(){
     console.log(" myevent happened");
});

var si=setInterval(function(){
    console.log("1111111");
    ee.emit("myevent");
    clearInterval(si);
    console.log("2222222");
},2000)