var fs=require("fs");

fs.mkdir("temp",function(){
    console.log("Temp directory created");
    fs.writeFile("temp/temp.txt"," Welcome to file");
    fs.exists("temp/temp.txt",function(){
        console.log("Temp directory found");
        fs.appendFile("temp/temp.txt","Second Entry",function(err){
            if(err) throw err;
        });
    })
});