// import { setInterval } from "timers";

var fs=require("fs");

 fs.writeFile("temp/temp.txt"," Welcome to file",function(){
     console.log("File ready");
 });

 setTimeout(function() {
     fs.readFile("temp/temp.txt",function(err,filedata){
         if(err){
            console.log(err);
         }else{
            console.log("data");
         }
     })
 }, 1000);