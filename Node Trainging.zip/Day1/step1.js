//console.log(" Welcome to Node JS");
var count=0;
    function somefun() {
       
        for (var index = 0; index < 10; index++) {
            count = index;
            console.log("inside loop "+ count);
        }
        console.log("Outside loop "+ index)
        console.log("Outside loop "+ count)
    } 
    somefun();