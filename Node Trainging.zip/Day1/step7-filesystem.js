var fs=require("fs");
fs.mkdir("temp",function(){
    console.log("Directory created");
    fs.wr
})

setTimeout(() => {
    fs.rmdirSync("temp");
    console.log("Directory removed");
}, 1000);