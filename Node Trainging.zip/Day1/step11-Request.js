var request = require("request");
var fs=require("fs");

var req=request("http://technicaltraining.com").pipe(fs.createWriteStream("mypage.html"));

req.on("finish",function(){
    console.log("file created");
})
