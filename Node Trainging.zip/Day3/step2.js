const express=require("express");
let app=express();
app.use(express.static(__dirname));
app.get("/",function(req,res){
    // res.sendFile("C:\\Infinite\\Node Trainging\\Day3\\index.html");   
    // res.sendFile(__dirname+"/web/index.html");
    res.sendFile("/web/index.html",{root : __dirname});
    // res.sendFile(process.cwd()+"/web/index.html")
})
app.get("/superman",function(req,res){
    res.sendFile(process.cwd()+"/web/superman.html");
})

app.get("/batman",function(req,res){
    res.sendFile(process.cwd()+"/web/batman.html");
})

app.get("*",function(req,res){
    res.send(" Page not found");
})

// express will run on 3000 by default
app.listen(3030,"::",function(err){
    if(err){
        console.log(err);
        throw err;
    }else{
        console.log("server running on port 3030");
    }
})