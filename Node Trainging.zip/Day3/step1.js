var http=require("http");
var fs=require("fs");

var server=http.createServer(function(req,res){
    console.log(req.url);
    fs.readFile("./"+req.url,function(err,data){
           if(data){
            res.writeHead(200,{"Content-Type" : "text\html"});
            var pdata= data.toString();
            pdata=pdata.replace("{{msg}}","POORNA HERE.")
            res.end(pdata);
        }else{
            res.writeHead(200,{"Content-Type" : "text\html"});
            res.end("Req page not found");
        }
    })
});

server.listen(2020,"localhost",function(err){
    if(err){
        console.log(err);
        throw err;
    }else{
        console.log("server running on port 2020");
    }
})