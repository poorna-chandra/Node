const express=require("express");
let app=express();
var fs=require("fs");
let heroData;
fs.readFile(process.cwd()+"/json/heros.json",function(err,data){
    if(err){
        console.log(err);
    }else{
        heroData = JSON.parse(data);
    }
});

app.get("/",function(req,res){
        res.send(" Hello Poorna here.")
})
app.get("/product/:prod",(req,res) => {
    var prod = req.params.prod;
    res.send(`<h1> Hello Poorna here. ${ prod } is available.</h1>`)
})

app.get("/batman",function(req,res){
    res.sendFile(process.cwd()+"/web/batman.html");
})

app.get("/data",function(req,res){
    res.send(heroData.heros);
})

app.get("*",function(req,res){
    res.send(" Page not found");
})

// express will run on 3000 by default
app.listen(4040,"::",function(err){
    if(err){
        console.log(err);
        throw err;
    }else{
        console.log("server running on port 4040");
    }
})